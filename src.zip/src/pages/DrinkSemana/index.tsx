import React from "react";

const DrinkSemanaPages: React.FC = () => {
  return <div>Teste Drink Semana</div>;
};

export default DrinkSemanaPages;
