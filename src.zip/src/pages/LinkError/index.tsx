import React from "react";
import { Container } from "./styles";

const PrincipalPages: React.FC = () => {
  return <Container>404 página não encontrada</Container>;
};

export default PrincipalPages;
